//
// Created by nilerrors on 2/24/24.
//

#ifndef DFA_DFA_H
#define DFA_DFA_H

#include <vector>
#include <unordered_map>
#include <string>
#include "json.hpp"

using json = nlohmann::json;
using symbol = char;

const int SYMBOL_SIZE = 1;

struct DFA_State
{
	std::string name;
	bool starting;
	bool accepting;
	std::unordered_map<symbol, DFA_State*> transitions;

	DFA_State(const std::string &name)
	{
		DFA_State::name = name;
		starting = false;
		accepting = false;
		transitions = {};
	}

	DFA_State(const std::string &name, bool isBegin, bool isEnd)
	{
		DFA_State::name = name;
		starting = isBegin;
		accepting = isEnd;
		transitions = {};
	}

	void addTransition(symbol symb, DFA_State* state_pointer)
	{
		transitions[symb] = state_pointer;
	}

	DFA_State* getState(symbol symb)
	{
		const auto state = transitions.find(symb);
		if (state == transitions.end())
			return nullptr;
		return state->second;
	}
};

class DFA
{
public:
	DFA();
	DFA(const std::string &file_path);
	virtual ~DFA();

	[[nodiscard]]
	bool accepts(const std::string& string) const;

	// deletes DFA on destruct
	void addState(DFA_State* state) { states.push_back(state); }
	void addTransition(const std::string &fromState, const std::string &toState, symbol onSymbol);

	void validateAlphabetAndStore(const nlohmann::basic_json<> &alphabet_array);
	void validateStatesAndStore(const nlohmann::basic_json<> &states_array);
	void validateTransitionsAndStore(const nlohmann::basic_json<> &transitions_array);

private:
	std::vector<symbol> alphabet;
	std::vector<DFA_State*> states;
	DFA_State* startingState{};
};


#endif //DFA_DFA_H
