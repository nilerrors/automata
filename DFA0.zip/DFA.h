//
// Created by nilerrors on 2/24/24.
//

#ifndef DFA_DFA_H
#define DFA_DFA_H

#include <vector>
#include <unordered_map>
#include <string>

using symbol = char;

struct DFA_State
{
	bool initial;
	bool end;
	std::unordered_map<symbol, DFA_State*> states_pointers;

	DFA_State()
	{
		initial = false;
		end = false;
		states_pointers = {};
	}

	DFA_State(bool isBegin, bool isEnd)
	{
		initial = isBegin;
		end = isEnd;
		states_pointers = {};
	}

	void addState(symbol symb, DFA_State* state_pointer)
	{
		states_pointers[symb] = state_pointer;
	}

	DFA_State* getState(symbol symb)
	{
		const auto state = states_pointers.find(symb);
		if (state == states_pointers.end())
			return nullptr;
		return state->second;
	}
};

class DFA
{
public:
	DFA();
	DFA(const std::vector<symbol>& alphabet);
	virtual ~DFA();

	bool accepts(const std::string& string) const;

	// deletes DFA on destruct
	void addState(DFA_State* state) { states.push_back(state); }

private:
	std::vector<symbol> alphabet;
	std::vector<DFA_State*> states;
	DFA_State* initialState;
};


#endif //DFA_DFA_H
