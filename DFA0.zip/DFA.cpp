//
// Created by nilerrors on 2/24/24.
//

#include "DFA.h"

DFA::DFA()
{
	alphabet = {'0', '1'};
	auto s0 = new DFA_State(true, true);
	auto s1 = new DFA_State();
	auto s2 = new DFA_State();
	initialState = s0;
	s0->addState('0', s0);
	s0->addState('1', s1);
	s1->addState('0', s1);
	s1->addState('1', s0);
	s2->addState('0', s1);
	s2->addState('1', s2);
}

DFA::DFA(const std::vector<symbol> &alphabet)
{
	DFA::alphabet = alphabet;
}

DFA::~DFA()
{
	for (DFA_State*& state : states)
	{
		delete state;
		state = nullptr;
	}
}

bool DFA::accepts(const std::string& string) const
{
	DFA_State* currentState = initialState;
	if (initialState == nullptr)
		return false;

	for (char c : string)
	{
		currentState = currentState->getState(c);
		if (currentState == nullptr)
			return false;
	}
	return currentState->end;
}
