//
// Created by nilerrors on 4/8/24.
//

#ifndef AUTOMATA_STATESTABLE_H
#define AUTOMATA_STATESTABLE_H

#include <vector>
#include <string>
#include <set>

class State;

class DFA;

struct StateEquivalence
{
    State *first;
    State *second;
    bool is_distinguishable;
    int on_iteration;

    StateEquivalence()
    {
        first = nullptr;
        second = nullptr;
        is_distinguishable = false;
        on_iteration = -1;
    }

    StateEquivalence(State *f, State *s, bool eqv)
    {
        first = f;
        second = s;
        is_distinguishable = eqv;
        on_iteration = -1;
    }
};

class StatesTable
{
public:
    StatesTable();

    virtual ~StatesTable();

    void from(const DFA *dfa);

    void fill();

    [[nodiscard]]
    std::vector<StateEquivalence> get_indistinguishable() const;

    [[nodiscard]]
    std::string to_string() const;

private:
    bool distinguishable(State *first, State *second) const;

private:
    std::vector<StateEquivalence> table;
    std::vector<State *> rows;
    std::vector<State *> cols;
    DFA const *fa = nullptr;
};


#endif //AUTOMATA_STATESTABLE_H
